Hello!, Atimus7 Here! 

Bringing you quality apocalypse cuisine without compromising balanced gameplay! Adds 51 new cooking recipes that can be made using vanilla items. 

To install:

1. Drag mod folder "VanillaCookingMod" into your "/Mods" folder directory in the "7 Days to Die" game folder. 
2. Eazshy Peazshy! now play the damn game and don't worry so much! 


List of content:

Hunters Feast: 
A hearty meal made from meat and vegetables, great for restoring health and stamina.

Savory Fish Stew: 
A warm stew made with fish and vegetables. It replenishes hunger and health.

Veggie Delight: 
A delicious vegetarian meal that provides a moderate amount of  and stamina.

Spicy Chili Pot: 
A spicy dish that fills you up and boosts your stamina.

Blueberry Pancakes: Fluffy pancakes with blueberries that provide a sweet boost of energy.

Grilled Meat Skewers: Grilled meat on a stick, a simple and satisfying meal.

Creamy Mushroom Soup: 
A creamy soup made with mushrooms, perfect for restoring health.

Sweet Pumpkin Pie: 
A sweet dessert made from pumpkins that boosts your health and stamina.

Canned Meat Casserole: 
A hearty casserole made from canned meat, great for long-lasting energy.

Golden Yucca Drink: 
A refreshing drink made from yucca fruit and goldenrod tea that restores thirst and health, cures infection by 5%.

Hobo Chili: 
A spicy chili made from canned cat . It fills you up and provides energy.

Pumpkin Corn bread: 
A sweet cornbread made with pumpkin, offering a good balance of hunger and health.

Fish Tacos Deluxe: Delicious fish tacos that restore both hunger and health.

Crispy Yucca Fries: Crispy fries made from yucca fruit, great for a quick snack.

Wild Game Stew: 
A hearty stew made from wild game meat, restoring hunger, health, and stamina.

Corn Fritters: Fried corn fritters that provide a moderate boost to health and stamina.

Hearty Omelet: 
A protein-rich omelet that restores a lot of hunger and stamina.

Sweet Corn Cake: 
A sweet treat made from cornmeal that provides a boost to stamina and health.

Goldenrod Herbal Soup: 
A medicinal soup made from goldenrod tea and herbs, providing healing benefits, cures infection by 5%, cures dysentery by 10%.

Roasted Mushroom Skewers: Skewers of roasted mushrooms, a simple dish that restores hunger.

Spicy Chili Drink: 
A spicy drink that warms you up and provides a stamina boost.

Pumpkin Stew: 
A filling stew made with pumpkin, great for restoring health and stamina.

Savory Meatballs: Juicy meatballs that provide a substantial amount of  and health.

Yucca Shake: 
A refreshing shake made with yucca fruit.

Corn Mushroom Soup: 
A light soup made with corn and mushrooms, perfect for a quick boost to health.

Spicy Meat Wrap: 
A spicy wrap filled with meat, providing a good amount of health and stamina.

Goldenrod Cornbread: Cornbread infused with goldenrod tea, offering mild health benefits, health regenerates 20% faster, cures dysentery by 10%.

Sauteed Blueberries: Sweet blueberries sauteed to perfection, great for a quick energy boost.

Herbal Mushroom Soup: 
A medicinal soup made with herbs and mushrooms, providing healing properties, cures infection by 5%, cures dysentery by 15%.

Yucca Fruit Salad: 
A refreshing salad made from yucca fruit, restoring hunger and stamina.

Cheesy Corn Casserole: 
A rich casserole made with cheese and corn, offering high  and health benefits.

Stuffed Mushrooms: Mushrooms stuffed with meat and herbs, perfect for a hearty meal.

Pumpkin Spice Bread: 
A sweet bread made with pumpkin and spices, great for a quick snack.

Savory Blueberry Soup: 
A unique soup made with blueberries, providing a mild health boost.

Meat loaf Supreme: 
A supreme meatloaf that fills you up and restores stamina.

Vegetable Skewers: Grilled vegetable skewers that provide a light and healthy meal.

Canned Stew: 
A simple stew made from canned ingredients, restoring hunger and health.

Fish Potato Platter: 
A hearty dish made with fish and potatoes, great for restoring health and stamina.

Spicy Chili Meatballs: Spicy meatballs that give a quick boost to health and stamina.

Yucca Pudding: 
A sweet pudding made from yucca fruit, providing a quick boost to health.

Hearty Corn Bean Stew: 
A hearty stew made from corn and beans, great for a satisfying meal.

Carrot Potato Mash: 
A smooth mash made from carrots and potatoes, restoring health and stamina.

Herb Infused Meat: Meat infused with herbs for extra flavor and healing properties, cures dysentery by 15%.

Grilled Veggie Platter: 
A platter of grilled vegetables, perfect for a healthy meal.

Mushroom Broth: 
A light broth made from mushrooms, offering mild health benefits.

Sweet Blueberry Juice: 
A sweet juice made from blueberries, restoring thirst and providing energy, cures infection by 2%.

Chrysanthemum Cooler: 
A cool drink made with chrysanthemum and snow, perfect for refreshing on hot days, aids in efficient digestion by 15%.

Herbal Energy: 
An energizing drink made with herbs, restoring stamina and health, cures infection by 5%, cures dysentery by 20%, aids in efficient digestion and stamina regen by 15%.

Spicy Chili Drink: What? You want water? Too bad. We're in a dessert.

Super Smoothie: 
A supercharged smoothie made with fresh ingredients, providing a large stamina boost, cures dysentery by 20%, cures infection by 2%, aids in efficient digestion by 15%.

Minty Fresh Tea: 
A refreshing tea made from Goldenrod Tea and Chrysanthemum, provides a stamina boost, cures infection by 2%, cures dysentery by 20%, aids in efficient digestion by 15%.

